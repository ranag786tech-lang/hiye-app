
import { GoogleGenAI, Modality, LiveServerMessage, Type } from "@google/genai";
import { HIYE_SYSTEM_PROMPT } from "../constants";
import { ChatHistoryItem, UserProfile } from "../types";

const getApiKey = () => {
  // Try dynamic injection first, then fallback to build-time key
  return (globalThis as any).process?.env?.API_KEY || process.env.API_KEY || '';
};

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: getApiKey() });
  }

  private getSystemInstruction(profile?: UserProfile) {
    let instruction = HIYE_SYSTEM_PROMPT;
    if (profile) {
      instruction += `\n\nUSER PROFILE:\n`;
      if (profile.name) instruction += `- Name: ${profile.name}\n`;
      if (profile.language) instruction += `- Preferred Language: ${profile.language}\n`;
      if (profile.timezone) instruction += `- Timezone: ${profile.timezone}\n`;
      if (profile.preferences?.length) instruction += `- Preferences: ${profile.preferences.join(', ')}\n`;
      if (profile.traits?.length) instruction += `- Known Traits: ${profile.traits.join(', ')}\n`;
      instruction += `\nAdapt your tone and language to match the user's preferences. Remember past interactions and build on them.`;
    }
    return instruction;
  }

  async generateResponse(prompt: string, isSerious: boolean = false, history: ChatHistoryItem[] = [], profile?: UserProfile) {
    // Ensure we use the latest key if it changed
    const ai = new GoogleGenAI({ apiKey: getApiKey() });
    const model = isSerious ? 'gemini-3.1-pro-preview' : 'gemini-3-flash-preview';
    const config: any = {
      systemInstruction: this.getSystemInstruction(profile),
      temperature: isSerious ? 0.2 : 0.8,
    };

    if (isSerious) {
      config.thinkingConfig = { thinkingBudget: 16000 };
      config.tools = [{ googleSearch: {} }];
    }

    const response = await ai.models.generateContent({
      model,
      contents: [...history, { role: 'user', parts: [{ text: prompt }] }],
      config,
    });

    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    const urls = groundingChunks.map((chunk: any) => ({
      title: chunk.web?.title || 'Resource',
      uri: chunk.web?.uri || '',
    })).filter((c: any) => c.uri);

    return {
      text: response.text || '',
      groundingUrls: urls,
    };
  }

  async extractProfile(history: ChatHistoryItem[], currentProfile: UserProfile): Promise<UserProfile> {
    const ai = new GoogleGenAI({ apiKey: getApiKey() });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [
        ...history,
        { 
          role: 'user', 
          parts: [{ text: `Based on our conversation, update the user profile. Return ONLY the updated JSON.
          Current Profile: ${JSON.stringify(currentProfile)}` }] 
        }
      ],
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            language: { type: Type.STRING },
            timezone: { type: Type.STRING },
            preferences: { type: Type.ARRAY, items: { type: Type.STRING } },
            traits: { type: Type.ARRAY, items: { type: Type.STRING } }
          }
        }
      }
    });

    try {
      return JSON.parse(response.text || '{}');
    } catch (e) {
      return currentProfile;
    }
  }

  connectLive(callbacks: {
    onopen: () => void;
    onmessage: (message: LiveServerMessage) => void;
    onerror: (e: any) => void;
    onclose: (e: any) => void;
  }, profile?: UserProfile) {
    // Create fresh instance per guidelines
    const ai = new GoogleGenAI({ apiKey: getApiKey() });
    return ai.live.connect({
      model: 'gemini-2.5-flash-native-audio-preview-09-2025',
      callbacks,
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } },
        },
        systemInstruction: this.getSystemInstruction(profile),
        // Enable transcriptions for better feedback
        inputAudioTranscription: {},
        outputAudioTranscription: {},
      },
    });
  }
}

export const gemini = new GeminiService();

export function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

export async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

export function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}
