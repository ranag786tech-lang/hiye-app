
import React, { useState, useRef, useEffect } from 'react';
import { Send, Zap, Heart, Trash2, Globe, Plus, Mic, ArrowUp, HardDrive, Upload, Camera } from 'lucide-react';
import { ChatMessage, AppMode } from '../types';

interface ChatInterfaceProps {
  messages: ChatMessage[];
  onSendMessage: (text: string) => void;
  onClear: () => void;
  isSerious: boolean;
  isLoading: boolean;
  isLiveActive: boolean;
  onToggleLive: () => void;
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({ 
  messages, onSendMessage, onClear, isSerious, isLoading, isLiveActive, onToggleLive
}) => {
  const [input, setInput] = useState('');
  const [showPlusMenu, setShowPlusMenu] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  // Auto-expand textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`;
    }
  }, [input]);

  const handleSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (input.trim() && !isLoading) {
      onSendMessage(input);
      setInput('');
      if (textareaRef.current) textareaRef.current.style.height = 'auto';
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onSendMessage(`[File Uploaded: ${file.name}]`);
      setShowPlusMenu(false);
    }
  };

  const handlePlusAction = (action: string) => {
    if (action === 'upload') {
      fileInputRef.current?.click();
    } else if (action === 'camera') {
      onSendMessage("[Opening Camera...]");
      setShowPlusMenu(false);
    } else if (action === 'drive') {
      onSendMessage("[Connecting to Google Drive...]");
      setShowPlusMenu(false);
    }
  };

  return (
    <div className={`flex flex-col h-[600px] w-full max-w-2xl mx-auto rounded-3xl overflow-hidden backdrop-blur-xl border transition-all duration-700 ${
      isSerious ? 'bg-slate-900/60 border-blue-500/30' : 'bg-neutral-900/40 border-amber-500/20'
    } shadow-2xl`}>
      {/* Header */}
      <div className="p-4 border-b border-white/10 flex justify-between items-center bg-white/5">
        <div className="flex items-center gap-2">
          {isSerious ? <Zap className="w-4 h-4 text-blue-400" /> : <Heart className="w-4 h-4 text-rose-400" />}
          <span className="font-semibold text-sm tracking-widest uppercase">
            {isSerious ? 'Focused Mode' : 'Loving Presence'}
          </span>
        </div>
        <button 
          onClick={onClear}
          className="p-2 hover:bg-white/10 rounded-full transition-colors opacity-60 hover:opacity-100"
          title="Clear Conversation"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6 scroll-smooth">
        {messages.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center opacity-40 text-center px-8">
            <p className="urdu-text text-3xl mb-4">السلام علیکم</p>
            <p className="text-sm italic">"I am here to listen with love and solve with wisdom."</p>
          </div>
        )}
        
        {messages.map((m) => (
          <div key={m.id} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] rounded-2xl px-5 py-3 ${
              m.role === 'user' 
                ? 'bg-white/10 text-white rounded-br-none' 
                : isSerious 
                  ? 'bg-blue-600/20 text-blue-50 border border-blue-400/30 rounded-bl-none'
                  : 'bg-amber-500/10 text-amber-50 border border-amber-400/20 rounded-bl-none'
            }`}>
              <p className="leading-relaxed whitespace-pre-wrap text-sm md:text-base">{m.content}</p>
              
              {m.groundingUrls && m.groundingUrls.length > 0 && (
                <div className="mt-3 pt-3 border-t border-white/10 flex flex-wrap gap-2">
                  {m.groundingUrls.map((url, idx) => (
                    <a 
                      key={idx} 
                      href={url.uri} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-[10px] bg-white/5 px-2 py-1 rounded hover:bg-white/10 transition-colors"
                    >
                      <Globe className="w-3 h-3" />
                      {url.title}
                    </a>
                  ))}
                </div>
              )}
              
              <span className="text-[10px] opacity-40 mt-2 block text-right">
                {m.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="flex justify-start">
            <div className={`px-5 py-3 rounded-2xl animate-pulse ${
              isSerious ? 'bg-blue-900/40' : 'bg-amber-900/40'
            }`}>
              <div className="flex gap-1">
                <div className="w-1.5 h-1.5 bg-current rounded-full animate-bounce" />
                <div className="w-1.5 h-1.5 bg-current rounded-full animate-bounce [animation-delay:0.2s]" />
                <div className="w-1.5 h-1.5 bg-current rounded-full animate-bounce [animation-delay:0.4s]" />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Input Area */}
      <div className="p-4 bg-white/5 border-t border-white/10 relative">
        <input 
          type="file" 
          ref={fileInputRef} 
          className="hidden" 
          onChange={handleFileUpload}
        />
        
        {/* Plus Menu Popup */}
        {showPlusMenu && (
          <div className="absolute bottom-full left-4 mb-2 w-48 bg-neutral-900 border border-white/10 rounded-2xl shadow-2xl overflow-hidden animate-in slide-in-from-bottom-2 duration-200 z-50">
            <button 
              onClick={() => handlePlusAction('drive')}
              className="w-full flex items-center gap-3 px-4 py-3 hover:bg-white/5 transition-colors text-sm"
            >
              <HardDrive className="w-4 h-4 text-blue-400" />
              <span>Google Drive</span>
            </button>
            <button 
              onClick={() => handlePlusAction('upload')}
              className="w-full flex items-center gap-3 px-4 py-3 hover:bg-white/5 transition-colors text-sm border-t border-white/5"
            >
              <Upload className="w-4 h-4 text-emerald-400" />
              <span>Upload Files</span>
            </button>
            <button 
              onClick={() => handlePlusAction('camera')}
              className="w-full flex items-center gap-3 px-4 py-3 hover:bg-white/5 transition-colors text-sm border-t border-white/5"
            >
              <Camera className="w-4 h-4 text-rose-400" />
              <span>Camera</span>
            </button>
          </div>
        )}

        <div className="flex items-end gap-2 bg-white/10 rounded-3xl p-2 px-3 focus-within:ring-2 focus-within:ring-amber-400/30 transition-all">
          <button 
            type="button"
            onClick={onToggleLive}
            className={`p-2 rounded-full transition-colors ${isLiveActive ? 'text-rose-500 bg-rose-500/10' : 'text-white/60 hover:text-white hover:bg-white/5'}`}
            title="Voice Chat"
          >
            <Mic className="w-5 h-5" />
          </button>

          <button 
            type="button"
            onClick={() => setShowPlusMenu(!showPlusMenu)}
            className={`p-2 rounded-full transition-colors ${showPlusMenu ? 'text-amber-400 bg-amber-400/10' : 'text-white/60 hover:text-white hover:bg-white/5'}`}
            title="Attach"
          >
            <Plus className={`w-5 h-5 transition-transform duration-200 ${showPlusMenu ? 'rotate-45' : ''}`} />
          </button>

          <textarea 
            ref={textareaRef}
            rows={1}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={isSerious ? "Submit a complex task..." : "Share your heart..."}
            className="flex-1 bg-transparent border-none py-2 px-2 text-sm focus:ring-0 outline-none resize-none min-h-[40px] max-h-[200px] overflow-y-auto"
          />

          <button 
            type="button"
            onClick={() => handleSubmit()}
            disabled={!input.trim() || isLoading}
            className={`p-2 rounded-full transition-all flex items-center justify-center disabled:opacity-30 ${
              isSerious ? 'text-blue-400 hover:bg-blue-400/10' : 'text-amber-400 hover:bg-amber-400/10'
            }`}
          >
            <ArrowUp className="w-6 h-6" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChatInterface;
