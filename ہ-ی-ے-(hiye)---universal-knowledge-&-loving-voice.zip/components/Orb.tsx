
import React from 'react';

interface OrbProps {
  isActive: boolean;
  isSerious: boolean;
  volume?: number; // 0 to 1
}

const Orb: React.FC<OrbProps> = ({ isActive, isSerious, volume = 0 }) => {
  // Scale factor based on volume (gentle pulse)
  const volScale = isActive ? 1 + (volume * 0.4) : 1;

  return (
    <div className="relative flex items-center justify-center w-64 h-64 md:w-80 md:h-80">
      {/* Outer Glow */}
      <div 
        className={`absolute inset-0 rounded-full blur-[60px] transition-all duration-300 ${
          isSerious 
            ? 'bg-blue-500/20' 
            : 'bg-amber-400/20'
        } ${isActive ? 'opacity-100' : 'opacity-60'}`} 
        style={{ transform: `scale(${volScale * 1.2})` }}
      />
      
      {/* Middle Ring */}
      <div 
        className={`absolute inset-4 rounded-full border border-white/10 animate-[spin_10s_linear_infinite] ${
          isSerious ? 'border-blue-300/20' : 'border-amber-200/20'
        }`} 
      />

      {/* Main Core */}
      <div 
        className={`relative w-40 h-40 md:w-48 md:h-48 rounded-full overflow-hidden transition-all duration-300 ${
          isSerious ? 'bg-slate-900 border-blue-400/50' : 'bg-neutral-900 border-amber-300/50'
        } border-2 shadow-2xl flex items-center justify-center group`}
        style={{ transform: `scale(${volScale})` }}
      >
        <div className={`absolute inset-0 bg-gradient-to-br transition-all duration-700 ${
          isSerious 
            ? 'from-blue-600/30 via-transparent to-indigo-900/40' 
            : 'from-amber-400/30 via-transparent to-rose-900/40'
        }`} />
        
        {/* The Urdu Symbol */}
        <span className={`urdu-text text-6xl md:text-7xl select-none transition-colors duration-700 ${
          isSerious ? 'text-blue-100' : 'text-amber-100'
        } drop-shadow-[0_0_15px_rgba(255,255,255,0.5)]`}>
          ہ ی ے
        </span>

        {/* Pulsing effect when active */}
        {isActive && (
          <div className="absolute inset-0 border-4 border-white/20 rounded-full animate-ping pointer-events-none" />
        )}
      </div>

      {/* Volume Visualizer Dots */}
      {isActive && (
        <div className="absolute -bottom-8 flex gap-1 h-4 items-end">
          {[...Array(5)].map((_, i) => (
            <div 
              key={i} 
              className={`w-1 rounded-full transition-all duration-75 ${isSerious ? 'bg-blue-400' : 'bg-amber-400'}`}
              style={{ height: `${Math.max(20, volume * 100 * (1 - Math.abs(2-i)*0.2))}%` }}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default Orb;
