
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Mic, MicOff, Settings, Info, Zap, Heart, Sparkles, Brain } from 'lucide-react';
import { gemini, decode, decodeAudioData, encode } from './services/gemini';
import { AppMode, ChatMessage, UserProfile, ChatHistoryItem } from './types';
import Orb from './components/Orb';
import ChatInterface from './components/ChatInterface';

const App: React.FC = () => {
  const [mode, setMode] = useState<AppMode>(AppMode.PLAYFUL);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [chatHistory, setChatHistory] = useState<ChatHistoryItem[]>([]);
  const [userProfile, setUserProfile] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('hiye_user_profile');
    return saved ? JSON.parse(saved) : {
      language: navigator.language,
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      preferences: [],
      traits: []
    };
  });
  const [isLiveActive, setIsLiveActive] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [micVolume, setMicVolume] = useState(0);
  const [transcription, setTranscription] = useState<{ user: string, ai: string }>({ user: '', ai: '' });
  const [hasApiKey, setHasApiKey] = useState(true);
  
  // Audio Refs
  const inputAudioCtx = useRef<AudioContext | null>(null);
  const outputAudioCtx = useRef<AudioContext | null>(null);
  const sessionRef = useRef<any>(null);
  const nextStartTime = useRef(0);
  const audioSources = useRef<Set<AudioBufferSourceNode>>(new Set());
  const micStream = useRef<MediaStream | null>(null);
  const processorNode = useRef<ScriptProcessorNode | null>(null);

  useEffect(() => {
    const checkApiKey = async () => {
      if (window.aistudio) {
        const selected = await window.aistudio.hasSelectedApiKey();
        setHasApiKey(selected);
      }
    };
    checkApiKey();
  }, []);

  useEffect(() => {
    localStorage.setItem('hiye_user_profile', JSON.stringify(userProfile));
  }, [userProfile]);

  const handleOpenKeySelector = async () => {
    if (window.aistudio) {
      await window.aistudio.openSelectKey();
      setHasApiKey(true); // Assume success per guidelines
    }
  };

  const toggleMode = () => {
    setMode(prev => prev === AppMode.PLAYFUL ? AppMode.SERIOUS : AppMode.PLAYFUL);
  };

  const clearChat = () => setMessages([]);

  const handleSendMessage = async (text: string) => {
    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: text,
      timestamp: new Date(),
      mode
    };
    
    setMessages(prev => [...prev, userMsg]);
    setIsLoading(true);

    try {
      const seriousKeywords = ['calculate', 'solve', 'physics', 'math', 'code', 'translate', 'serious', 'task'];
      const shouldBeSerious = seriousKeywords.some(kw => text.toLowerCase().includes(kw));
      if (shouldBeSerious && mode === AppMode.PLAYFUL) setMode(AppMode.SERIOUS);

      const response = await gemini.generateResponse(text, mode === AppMode.SERIOUS || shouldBeSerious, chatHistory, userProfile);
      
      const aiMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response.text,
        timestamp: new Date(),
        mode: mode === AppMode.SERIOUS || shouldBeSerious ? AppMode.SERIOUS : AppMode.PLAYFUL,
        groundingUrls: response.groundingUrls
      };

      setMessages(prev => [...prev, aiMsg]);

      // Update History
      const newHistory: ChatHistoryItem[] = [
        ...chatHistory,
        { role: 'user', parts: [{ text }] },
        { role: 'model', parts: [{ text: response.text }] }
      ].slice(-20); // Keep last 10 turns
      setChatHistory(newHistory);

      // Periodically update profile (every 3 messages)
      if (newHistory.length % 6 === 0) {
        const updatedProfile = await gemini.extractProfile(newHistory, userProfile);
        setUserProfile(prev => ({ ...prev, ...updatedProfile }));
      }

    } catch (err) {
      console.error(err);
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: "I couldn't quite grasp that. Let's try once more.",
        timestamp: new Date(),
        mode: AppMode.PLAYFUL
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const startLiveSession = async () => {
    if (!hasApiKey) {
      handleOpenKeySelector();
      return;
    }
    try {
      // Create and Resume AudioContext immediately on interaction
      if (!inputAudioCtx.current) {
        inputAudioCtx.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      }
      if (!outputAudioCtx.current) {
        outputAudioCtx.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      }

      await Promise.all([
        inputAudioCtx.current.resume(),
        outputAudioCtx.current.resume()
      ]);

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      micStream.current = stream;

      const sessionPromise = gemini.connectLive({
        onopen: () => {
          setIsLiveActive(true);
          setTranscription({ user: '', ai: '' });
          
          try {
            const source = inputAudioCtx.current!.createMediaStreamSource(stream);
            const scriptProcessor = inputAudioCtx.current!.createScriptProcessor(4096, 1, 1);
            processorNode.current = scriptProcessor;
            
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              
              // Calculate volume for UI feedback
              let sum = 0;
              for (let i = 0; i < inputData.length; i++) {
                sum += inputData[i] * inputData[i];
              }
              const rms = Math.sqrt(sum / inputData.length);
              setMicVolume(Math.min(1, rms * 5)); // Boost for visibility

              const l = inputData.length;
              const int16 = new Int16Array(l);
              for (let i = 0; i < l; i++) {
                int16[i] = inputData[i] * 32768;
              }
              const pcmBlob = {
                data: encode(new Uint8Array(int16.buffer)),
                mimeType: 'audio/pcm;rate=16000',
              };
              
              sessionPromise.then(session => {
                session.sendRealtimeInput({ media: pcmBlob });
              }).catch(err => {
                console.error("Session input error:", err);
              });
            };

            source.connect(scriptProcessor);
            scriptProcessor.connect(inputAudioCtx.current!.destination);
          } catch (audioErr) {
            console.error("Audio pipeline error:", audioErr);
            stopLiveSession();
          }
        },
        onmessage: async (message) => {
          // Handle Audio
          const audioBase64 = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
          if (audioBase64 && outputAudioCtx.current) {
            nextStartTime.current = Math.max(nextStartTime.current, outputAudioCtx.current.currentTime);
            try {
              const audioBuffer = await decodeAudioData(
                decode(audioBase64),
                outputAudioCtx.current,
                24000,
                1
              );
              const source = outputAudioCtx.current.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(outputAudioCtx.current.destination);
              source.start(nextStartTime.current);
              nextStartTime.current += audioBuffer.duration;
              audioSources.current.add(source);
              source.onended = () => audioSources.current.delete(source);
            } catch (decodeErr) {
              console.error("Audio decode error:", decodeErr);
            }
          }

          // Handle Transcriptions
          if (message.serverContent?.inputAudioTranscription) {
            setTranscription(prev => ({ ...prev, user: message.serverContent?.inputAudioTranscription?.text || '' }));
          }
          if (message.serverContent?.outputAudioTranscription) {
            setTranscription(prev => ({ ...prev, ai: (prev.ai + (message.serverContent?.outputAudioTranscription?.text || '')) }));
          }
          if (message.serverContent?.turnComplete) {
            // Push full interaction to chat log when turn completes
            setMessages(prev => [
              ...prev, 
              { id: Date.now().toString(), role: 'user', content: transcription.user, timestamp: new Date(), mode: AppMode.PLAYFUL },
              { id: (Date.now() + 1).toString(), role: 'assistant', content: transcription.ai, timestamp: new Date(), mode: AppMode.PLAYFUL }
            ]);

            // Update History for Live session
            setChatHistory(prev => [
              ...prev,
              { role: 'user', parts: [{ text: transcription.user }] },
              { role: 'model', parts: [{ text: transcription.ai }] }
            ].slice(-20));

            setTranscription({ user: '', ai: '' });
          }

          if (message.serverContent?.interrupted) {
            audioSources.current.forEach(s => { try { s.stop(); } catch(e) {} });
            audioSources.current.clear();
            nextStartTime.current = 0;
            setTranscription({ user: '', ai: '' });
          }
        },
        onerror: (e) => {
          console.error("Live Error:", e);
          stopLiveSession();
        },
        onclose: () => {
          stopLiveSession();
        }
      }, userProfile);

      sessionRef.current = await sessionPromise;
    } catch (err) {
      console.error("Mic start failed:", err);
      setIsLiveActive(false);
      alert("Microphone access failed. Please check permissions.");
    }
  };

  const stopLiveSession = useCallback(() => {
    if (processorNode.current) {
      processorNode.current.disconnect();
      processorNode.current = null;
    }
    if (micStream.current) {
      micStream.current.getTracks().forEach(track => track.stop());
      micStream.current = null;
    }
    audioSources.current.forEach(s => { try { s.stop(); } catch(e) {} });
    audioSources.current.clear();
    nextStartTime.current = 0;
    setMicVolume(0);
    setIsLiveActive(false);
  }, []);

  return (
    <div className="min-h-screen flex flex-col items-center justify-start p-4 md:p-8 space-y-12 pb-32">
      {/* Navbar */}
      <nav className="w-full max-w-6xl flex justify-between items-center bg-white/5 backdrop-blur-md rounded-2xl p-4 border border-white/10">
        <div className="flex items-center gap-3">
          <div className={`p-2 rounded-lg ${mode === AppMode.SERIOUS ? 'bg-blue-600/20 text-blue-400' : 'bg-amber-500/20 text-amber-400'}`}>
            <Sparkles className="w-6 h-6" />
          </div>
          <div>
            <h1 className="urdu-text text-2xl font-bold tracking-wider leading-none">ہ ی ے</h1>
            <p className="text-[10px] uppercase tracking-[0.2em] opacity-50 font-bold">Universal Essence</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          {!hasApiKey && (
            <div className="flex flex-col items-end gap-1">
              <button 
                onClick={handleOpenKeySelector}
                className="flex items-center gap-2 px-4 py-2 rounded-full bg-rose-500/20 text-rose-400 border border-rose-500/30 hover:bg-rose-500/30 transition-all text-xs font-bold uppercase tracking-widest"
              >
                <Zap className="w-4 h-4" />
                Connect API Key
              </button>
              <a 
                href="https://ai.google.dev/gemini-api/docs/billing" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-[9px] opacity-40 hover:opacity-100 transition-opacity underline"
              >
                Billing Info
              </a>
            </div>
          )}
          <button 
            onClick={toggleMode}
            className={`flex items-center gap-2 px-4 py-2 rounded-full border transition-all duration-500 ${
              mode === AppMode.SERIOUS 
                ? 'bg-blue-600 text-white border-blue-400 shadow-lg shadow-blue-500/20' 
                : 'bg-white/5 text-amber-100 border-white/10 hover:bg-white/10'
            }`}
          >
            {mode === AppMode.SERIOUS ? <Brain className="w-4 h-4" /> : <Heart className="w-4 h-4" />}
            <span className="text-xs font-bold uppercase tracking-widest hidden sm:inline">
              {mode === AppMode.SERIOUS ? 'Serious Focus' : 'Gentle Heart'}
            </span>
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="flex flex-col items-center gap-8 w-full max-w-4xl relative">
        <Orb isActive={isLiveActive || isLoading} isSerious={mode === AppMode.SERIOUS} volume={micVolume} />
        
        {/* Real-time Transcription Overlay */}
        {isLiveActive && (
          <div className="absolute top-64 w-full max-w-md text-center bg-black/40 backdrop-blur-md p-4 rounded-xl border border-white/10 animate-in fade-in slide-in-from-bottom-4 duration-500">
            {transcription.user && (
              <p className="text-white/80 text-sm mb-2 italic">"{transcription.user}"</p>
            )}
            {transcription.ai && (
              <p className={`text-lg font-medium ${mode === AppMode.SERIOUS ? 'text-blue-300' : 'text-amber-300'}`}>
                {transcription.ai}
              </p>
            )}
            {!transcription.user && !transcription.ai && (
              <p className="text-white/40 text-xs animate-pulse">listening with love...</p>
            )}
          </div>
        )}

        <div className="text-center space-y-3 pt-12">
          <h2 className={`text-4xl md:text-5xl font-bold tracking-tight transition-colors duration-700 ${
            mode === AppMode.SERIOUS ? 'text-blue-100' : 'text-amber-50'
          }`}>
            {mode === AppMode.SERIOUS ? 'Calculated Clarity.' : 'Whispers of Wisdom.'}
          </h2>
        </div>
      </section>

      {/* Control Panel */}
      <div className="flex flex-col items-center gap-6">
        <button 
          onClick={isLiveActive ? stopLiveSession : startLiveSession}
          className={`flex items-center gap-3 px-8 py-4 rounded-full font-bold transition-all transform hover:scale-105 active:scale-95 ${
            isLiveActive 
              ? 'bg-rose-600 shadow-rose-500/40 animate-pulse' 
              : mode === AppMode.SERIOUS 
                ? 'bg-blue-600 hover:bg-blue-500 shadow-blue-500/40' 
                : 'bg-amber-500 hover:bg-amber-400 shadow-amber-500/40'
          } shadow-2xl text-white`}
        >
          {isLiveActive ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
          <span>{isLiveActive ? 'End Conversation' : 'Speak with Love'}</span>
        </button>
      </div>

      {/* Main Interaction Area */}
      <main className="w-full flex flex-col items-center">
        <ChatInterface 
          messages={messages} 
          onSendMessage={handleSendMessage} 
          onClear={clearChat}
          isSerious={mode === AppMode.SERIOUS}
          isLoading={isLoading}
          isLiveActive={isLiveActive}
          onToggleLive={isLiveActive ? stopLiveSession : startLiveSession}
        />
      </main>

      {/* Footer Info */}
      <footer className="w-full max-w-2xl py-8 flex flex-col items-center gap-6 opacity-40">
        <div className="flex gap-8 text-[11px] uppercase tracking-widest font-bold">
          <span className="flex items-center gap-2"><Info className="w-3 h-3" /> Spiritual Intelligence</span>
          <span className="flex items-center gap-2"><Info className="w-3 h-3" /> Data Wisdom</span>
        </div>
      </footer>
    </div>
  );
};

export default App;
