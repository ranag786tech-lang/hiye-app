
export enum AppMode {
  PLAYFUL = 'PLAYFUL',
  SERIOUS = 'SERIOUS'
}

export interface UserProfile {
  name?: string;
  language?: string;
  timezone?: string;
  preferences?: string[];
  lastInteraction?: Date;
  traits?: string[];
}

export interface ChatHistoryItem {
  role: 'user' | 'model';
  parts: { text: string }[];
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  mode: AppMode;
  groundingUrls?: { title: string; uri: string }[];
}

export interface TranscriptionItem {
  text: string;
  role: 'user' | 'model';
}

declare global {
  interface Window {
    aistudio: {
      hasSelectedApiKey: () => Promise<boolean>;
      openSelectKey: () => Promise<void>;
    };
  }
}
